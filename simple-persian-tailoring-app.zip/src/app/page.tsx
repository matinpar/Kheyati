"use client";

import { useState, useEffect, useCallback } from "react";
import { Toaster } from "react-hot-toast";
import Header from "@/components/Header";
import DashboardTab from "@/components/DashboardTab";
import OrdersTab from "@/components/OrdersTab";
import CustomersTab from "@/components/CustomersTab";
import BackupTab from "@/components/BackupTab";

export type Tab = "dashboard" | "orders" | "customers" | "backup";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("tailoring-dark-mode");
    if (stored === "true") setDarkMode(true);
  }, []);

  const toggleDarkMode = useCallback(() => {
    setDarkMode((prev) => {
      const next = !prev;
      localStorage.setItem("tailoring-dark-mode", String(next));
      return next;
    });
  }, []);

  return (
    <div className={darkMode ? "dark" : ""}>
      <div className="min-h-screen bg-rose-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors">
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 3000,
            style: {
              fontSize: "1rem",
              fontFamily: "inherit",
            },
          }}
        />
        <Header
          activeTab={activeTab}
          onTabChange={setActiveTab}
          darkMode={darkMode}
          onToggleDarkMode={toggleDarkMode}
        />
        <main className="max-w-4xl mx-auto px-4 pb-24 pt-4">
          {activeTab === "dashboard" && <DashboardTab onTabChange={setActiveTab} />}
          {activeTab === "orders" && <OrdersTab />}
          {activeTab === "customers" && <CustomersTab />}
          {activeTab === "backup" && <BackupTab />}
        </main>
      </div>
    </div>
  );
}
