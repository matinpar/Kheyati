import { db } from "@/db";
import { measurements } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  try {
    const [result] = await db
      .select()
      .from(measurements)
      .where(eq(measurements.orderId, parseInt(id)));
    return NextResponse.json(result || null);
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
