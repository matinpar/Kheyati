import { db } from "@/db";
import { orders, measurements, orderPhotos, customers } from "@/db/schema";
import { eq, ilike, or, asc, and, SQL } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const search = request.nextUrl.searchParams.get("search") || "";
  const customerId = request.nextUrl.searchParams.get("customerId");
  const status = request.nextUrl.searchParams.get("status");
  const upcoming = request.nextUrl.searchParams.get("upcoming");

  try {
    const conditions: SQL[] = [];

    if (customerId) {
      conditions.push(eq(orders.customerId, parseInt(customerId)));
    }
    if (status) {
      conditions.push(eq(orders.status, status));
    }
    if (search) {
      conditions.push(
        or(
          ilike(customers.name, `%${search}%`),
          ilike(customers.phone, `%${search}%`)
        )!
      );
    }
    if (upcoming === "true") {
      conditions.push(
        or(
          eq(orders.status, "in_progress"),
          eq(orders.status, "ready")
        )!
      );
    }

    const baseQuery = db
      .select({
        id: orders.id,
        customerId: orders.customerId,
        clothingType: orders.clothingType,
        fabricColor: orders.fabricColor,
        orderDate: orders.orderDate,
        deliveryDate: orders.deliveryDate,
        totalAmount: orders.totalAmount,
        advancePaid: orders.advancePaid,
        remainingAmount: orders.remainingAmount,
        status: orders.status,
        notes: orders.notes,
        createdAt: orders.createdAt,
        customerName: customers.name,
        customerPhone: customers.phone,
      })
      .from(orders)
      .leftJoin(customers, eq(orders.customerId, customers.id))
      .$dynamic();

    let builtQuery = baseQuery;
    if (conditions.length > 0) {
      builtQuery = baseQuery.where(and(...conditions)!);
    }

    const result = await builtQuery.orderBy(asc(orders.deliveryDate));
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const [order] = await db
      .insert(orders)
      .values({
        customerId: body.customerId,
        clothingType: body.clothingType,
        fabricColor: body.fabricColor || "",
        orderDate: body.orderDate,
        deliveryDate: body.deliveryDate,
        totalAmount: body.totalAmount || "0",
        advancePaid: body.advancePaid || "0",
        remainingAmount: body.remainingAmount || "0",
        status: body.status || "in_progress",
        notes: body.notes || "",
      })
      .returning();

    const meas = body.measurements;
    if (meas && order) {
      await db.insert(measurements).values({
        orderId: order.id,
        bust: meas.bust || "",
        waist: meas.waist || "",
        hips: meas.hips || "",
        shoulder: meas.shoulder || "",
        sleeveLength: meas.sleeveLength || "",
        dressLength: meas.dressLength || "",
        pantsLength: meas.pantsLength || "",
        other: meas.other || "",
      }).onConflictDoNothing();
    }

    const photos: string[] = body.photos || [];
    if (photos.length > 0 && order) {
      for (const dataUrl of photos) {
        await db.insert(orderPhotos).values({
          orderId: order.id,
          dataUrl,
        });
      }
    }

    return NextResponse.json(order, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const [order] = await db
      .update(orders)
      .set({
        customerId: body.customerId,
        clothingType: body.clothingType,
        fabricColor: body.fabricColor || "",
        orderDate: body.orderDate,
        deliveryDate: body.deliveryDate,
        totalAmount: body.totalAmount || "0",
        advancePaid: body.advancePaid || "0",
        remainingAmount: body.remainingAmount || "0",
        status: body.status || "in_progress",
        notes: body.notes || "",
      })
      .where(eq(orders.id, body.id))
      .returning();

    const meas = body.measurements;
    if (meas && order) {
      await db
        .delete(measurements)
        .where(eq(measurements.orderId, order.id));
      await db.insert(measurements).values({
        orderId: order.id,
        bust: meas.bust || "",
        waist: meas.waist || "",
        hips: meas.hips || "",
        shoulder: meas.shoulder || "",
        sleeveLength: meas.sleeveLength || "",
        dressLength: meas.dressLength || "",
        pantsLength: meas.pantsLength || "",
        other: meas.other || "",
      });
    }

    const photos: string[] | undefined = body.photos;
    if (photos !== undefined && order) {
      await db
        .delete(orderPhotos)
        .where(eq(orderPhotos.orderId, order.id));
      for (const dataUrl of photos) {
        await db.insert(orderPhotos).values({
          orderId: order.id,
          dataUrl,
        });
      }
    }

    return NextResponse.json(order);
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const id = request.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  try {
    await db.delete(orders).where(eq(orders.id, parseInt(id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
