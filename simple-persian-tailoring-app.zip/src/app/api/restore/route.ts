import { db } from "@/db";
import { customers, orders, measurements, orderPhotos } from "@/db/schema";
import { NextRequest, NextResponse } from "next/server";
import { sql } from "drizzle-orm";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (!body.version || !body.customers || !body.orders) {
      return NextResponse.json(
        { error: "فرمت فایل پشتیبان نامعتبر است" },
        { status: 400 }
      );
    }

    // Clear existing data (order matters for FK)
    await db.delete(orderPhotos);
    await db.delete(measurements);
    await db.delete(orders);
    await db.delete(customers);

    // Reset sequences
    await db.execute(sql`ALTER SEQUENCE customers_id_seq RESTART WITH 1`);
    await db.execute(sql`ALTER SEQUENCE orders_id_seq RESTART WITH 1`);
    await db.execute(sql`ALTER SEQUENCE measurements_id_seq RESTART WITH 1`);
    await db.execute(sql`ALTER SEQUENCE order_photos_id_seq RESTART WITH 1`);

    // Insert customers
    if (body.customers.length > 0) {
      await db.insert(customers).values(body.customers);
    }

    // Insert orders
    if (body.orders.length > 0) {
      await db.insert(orders).values(body.orders);
    }

    // Insert measurements
    if (body.measurements && body.measurements.length > 0) {
      await db.insert(measurements).values(body.measurements);
    }

    // Insert photos
    if (body.orderPhotos && body.orderPhotos.length > 0) {
      await db.insert(orderPhotos).values(body.orderPhotos);
    }

    return NextResponse.json({ ok: true, message: "بازیابی با موفقیت انجام شد" });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
