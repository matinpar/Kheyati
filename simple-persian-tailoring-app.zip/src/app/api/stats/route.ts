import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const inProgress = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orders)
      .where(eq(orders.status, "in_progress"));
    const ready = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orders)
      .where(eq(orders.status, "ready"));
    const delivered = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(orders)
      .where(eq(orders.status, "delivered"));

    return NextResponse.json({
      inProgress: inProgress[0]?.count ?? 0,
      ready: ready[0]?.count ?? 0,
      delivered: delivered[0]?.count ?? 0,
    });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
