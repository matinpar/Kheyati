import { db } from "@/db";
import { customers } from "@/db/schema";
import { eq, ilike, or } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const search = request.nextUrl.searchParams.get("search") || "";
  try {
    let result;
    if (search) {
      result = await db
        .select()
        .from(customers)
        .where(
          or(
            ilike(customers.name, `%${search}%`),
            ilike(customers.phone, `%${search}%`)
          )
        )
        .orderBy(customers.name);
    } else {
      result = await db.select().from(customers).orderBy(customers.name);
    }
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const [result] = await db.insert(customers).values({
      name: body.name,
      phone: body.phone,
      address: body.address || "",
      notes: body.notes || "",
    }).returning();
    return NextResponse.json(result, { status: 201 });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const [result] = await db
      .update(customers)
      .set({
        name: body.name,
        phone: body.phone,
        address: body.address || "",
        notes: body.notes || "",
      })
      .where(eq(customers.id, body.id))
      .returning();
    return NextResponse.json(result);
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  const id = request.nextUrl.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  try {
    await db.delete(customers).where(eq(customers.id, parseInt(id)));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
