import { db } from "@/db";
import { customers, orders, measurements, orderPhotos } from "@/db/schema";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const allCustomers = await db.select().from(customers);
    const allOrders = await db.select().from(orders);
    const allMeasurements = await db.select().from(measurements);
    const allPhotos = await db.select().from(orderPhotos);

    const backup = {
      version: 1,
      exportedAt: new Date().toISOString(),
      customers: allCustomers,
      orders: allOrders,
      measurements: allMeasurements,
      orderPhotos: allPhotos,
    };

    return NextResponse.json(backup);
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
