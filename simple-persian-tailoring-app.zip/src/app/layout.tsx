import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "مدیریت خیاطی",
  description: "اپلیکیشن مدیریت سفارش‌های خیاطی",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-rose-50 text-gray-900 antialiased min-h-screen">
        {children}
      </body>
    </html>
  );
}
