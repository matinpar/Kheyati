import {
  pgTable,
  text,
  timestamp,
  integer,
  decimal,
  boolean,
  serial,
} from "drizzle-orm/pg-core";

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  address: text("address").default(""),
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id")
    .references(() => customers.id, { onDelete: "cascade" })
    .notNull(),
  clothingType: text("clothing_type").notNull(),
  fabricColor: text("fabric_color").default(""),
  orderDate: text("order_date").notNull(),
  deliveryDate: text("delivery_date").notNull(),
  totalAmount: decimal("total_amount", { precision: 12, scale: 2 })
    .notNull()
    .default("0"),
  advancePaid: decimal("advance_paid", { precision: 12, scale: 2 })
    .notNull()
    .default("0"),
  remainingAmount: decimal("remaining_amount", { precision: 12, scale: 2 })
    .notNull()
    .default("0"),
  status: text("status").notNull().default("in_progress"), // in_progress, ready, delivered
  notes: text("notes").default(""),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const measurements = pgTable("measurements", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .references(() => orders.id, { onDelete: "cascade" })
    .notNull()
    .unique(),
  bust: text("bust").default(""),
  waist: text("waist").default(""),
  hips: text("hips").default(""),
  shoulder: text("shoulder").default(""),
  sleeveLength: text("sleeve_length").default(""),
  dressLength: text("dress_length").default(""),
  pantsLength: text("pants_length").default(""),
  other: text("other").default(""),
});

export const orderPhotos = pgTable("order_photos", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .references(() => orders.id, { onDelete: "cascade" })
    .notNull(),
  dataUrl: text("data_url").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
