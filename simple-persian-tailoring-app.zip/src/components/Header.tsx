"use client";

import { Tab } from "@/app/page";
import { Scissors, Users, LayoutDashboard, Database, Moon, Sun } from "lucide-react";

interface HeaderProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

const tabs: { key: Tab; label: string; icon: React.ReactNode }[] = [
  { key: "dashboard", label: "پیشخوان", icon: <LayoutDashboard size={22} /> },
  { key: "orders", label: "سفارش‌ها", icon: <Scissors size={22} /> },
  { key: "customers", label: "مشتریان", icon: <Users size={22} /> },
  { key: "backup", label: "پشتیبان", icon: <Database size={22} /> },
];

export default function Header({ activeTab, onTabChange, darkMode, onToggleDarkMode }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md border-b border-rose-200 dark:border-gray-700 shadow-sm">
      <div className="max-w-4xl mx-auto px-4 flex items-center justify-between h-16">
        <h1 className="text-xl font-bold text-rose-700 dark:text-rose-400 flex items-center gap-2">
          <Scissors size={26} />
          <span className="hidden sm:inline">مدیریت خیاطی</span>
        </h1>

        <nav className="flex items-center gap-1">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => onTabChange(tab.key)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                activeTab === tab.key
                  ? "bg-rose-600 text-white shadow-lg shadow-rose-200 dark:shadow-rose-900/30"
                  : "text-gray-600 dark:text-gray-300 hover:bg-rose-100 dark:hover:bg-gray-700"
              }`}
            >
              {tab.icon}
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          ))}
          <button
            onClick={onToggleDarkMode}
            className="p-2 rounded-xl text-gray-500 dark:text-gray-300 hover:bg-rose-100 dark:hover:bg-gray-700 transition-all ml-1"
            title={darkMode ? "حالت روشن" : "حالت تیره"}
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </nav>
      </div>
    </header>
  );
}
