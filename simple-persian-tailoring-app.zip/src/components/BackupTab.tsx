"use client";

import { useRef, useState } from "react";
import toast from "react-hot-toast";
import { Download, Upload, AlertTriangle } from "lucide-react";

export default function BackupTab() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [restoring, setRestoring] = useState(false);

  async function handleExport() {
    try {
      const res = await fetch("/api/backup");
      const data = await res.json();
      if (data.error) {
        toast.error(data.error);
        return;
      }
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `backup-${new Date().toISOString().split("T")[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success("نسخه پشتیبان با موفقیت تهیه شد ✅");
    } catch {
      toast.error("خطا در تهیه نسخه پشتیبان");
    }
  }

  async function handleRestore(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setRestoring(true);
    try {
      const text = await file.text();
      const data = JSON.parse(text);

      const res = await fetch("/api/restore", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const result = await res.json();

      if (result.error) {
        toast.error(result.error);
      } else {
        toast.success(result.message || "بازیابی با موفقیت انجام شد ✅");
      }
    } catch {
      toast.error("خطا در بازیابی فایل. لطفاً از معتبر بودن فایل اطمینان حاصل کنید.");
    } finally {
      setRestoring(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  return (
    <div className="space-y-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-rose-200 dark:border-gray-700 space-y-6">
        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100 text-center">
          تهیه نسخه پشتیبان و بازیابی
        </h2>

        {/* Export */}
        <div className="text-center space-y-3">
          <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/40 mx-auto flex items-center justify-center">
            <Download size={32} className="text-green-600 dark:text-green-400" />
          </div>
          <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200">تهیه نسخه پشتیبان</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            تمام اطلاعات شامل مشتریان، سفارش‌ها، اندازه‌ها و عکس‌ها در یک فایل ذخیره می‌شود.
          </p>
          <button
            onClick={handleExport}
            className="inline-flex items-center gap-2 py-3 px-6 rounded-xl bg-green-600 text-white text-lg font-medium hover:bg-green-700 transition-all shadow-lg shadow-green-200 dark:shadow-green-900/30"
          >
            <Download size={22} />
            دانلود نسخه پشتیبان
          </button>
        </div>

        <hr className="border-gray-200 dark:border-gray-700" />

        {/* Restore */}
        <div className="text-center space-y-3">
          <div className="w-16 h-16 rounded-full bg-amber-100 dark:bg-amber-900/40 mx-auto flex items-center justify-center">
            <Upload size={32} className="text-amber-600 dark:text-amber-400" />
          </div>
          <h3 className="text-lg font-bold text-gray-700 dark:text-gray-200">بازیابی اطلاعات</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            با انتخاب فایل پشتیبان، تمام اطلاعات قبلی جایگزین خواهد شد.
          </p>

          <div className="bg-amber-50 dark:bg-amber-900/20 rounded-xl p-3 flex items-start gap-2 text-sm text-amber-700 dark:text-amber-300">
            <AlertTriangle size={18} className="flex-shrink-0 mt-0.5" />
            <span>هشدار: تمام اطلاعات فعلی با اطلاعات فایل پشتیبان جایگزین می‌شود و قابل بازگشت نیست.</span>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleRestore}
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={restoring}
            className="inline-flex items-center gap-2 py-3 px-6 rounded-xl bg-amber-600 text-white text-lg font-medium hover:bg-amber-700 transition-all shadow-lg shadow-amber-200 dark:shadow-amber-900/30 disabled:opacity-50"
          >
            <Upload size={22} />
            {restoring ? "در حال بازیابی..." : "انتخاب فایل و بازیابی"}
          </button>
        </div>
      </div>
    </div>
  );
}
