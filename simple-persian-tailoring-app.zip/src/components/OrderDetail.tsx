"use client";

import { useState, useEffect } from "react";
import { X, Edit3 } from "lucide-react";
import type { Order, Measurement, OrderPhoto } from "@/lib/api";

interface OrderDetailProps {
  order: Order;
  onClose: () => void;
  onEdit: (order: Order) => void;
}

export default function OrderDetail({ order, onClose, onEdit }: OrderDetailProps) {
  const [measurements, setMeasurements] = useState<Measurement | null>(null);
  const [photos, setPhotos] = useState<OrderPhoto[]>([]);

  useEffect(() => {
    fetch(`/api/orders/${order.id}/measurements`)
      .then((r) => r.json())
      .then((data) => {
        if (data && !data.error) setMeasurements(data);
      })
      .catch(() => {});
    fetch(`/api/orders/${order.id}/photos`)
      .then((r) => r.json())
      .then((data) => {
        if (data && !data.error) setPhotos(data);
      })
      .catch(() => {});
  }, [order.id]);

  const statusLabel = (s: string) =>
    s === "in_progress" ? "در حال دوخت" : s === "ready" ? "آماده تحویل" : "تحویل داده شده";

  const measFields = [
    { key: "bust" as const, label: "دور سینه" },
    { key: "waist" as const, label: "دور کمر" },
    { key: "hips" as const, label: "دور باسن" },
    { key: "shoulder" as const, label: "سرشانه" },
    { key: "sleeveLength" as const, label: "قد آستین" },
    { key: "dressLength" as const, label: "قد لباس" },
    { key: "pantsLength" as const, label: "قد شلوار" },
    { key: "other" as const, label: "سایر" },
  ];

  const hasMeasurements = measurements && measFields.some((f) => measurements[f.key]);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 overflow-y-auto py-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-lg mx-4 shadow-2xl my-4">
        <div className="sticky top-0 bg-white dark:bg-gray-800 rounded-t-2xl border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">جزئیات سفارش</h2>
          <div className="flex items-center gap-1">
            <button
              onClick={() => onEdit(order)}
              className="p-2 rounded-lg hover:bg-rose-100 dark:hover:bg-rose-900/30 text-rose-600"
              title="ویرایش"
            >
              <Edit3 size={20} />
            </button>
            <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
              <X size={22} />
            </button>
          </div>
        </div>

        <div className="p-4 space-y-4 overflow-y-auto max-h-[75vh]">
          {/* Basic Info */}
          <div className="bg-rose-50 dark:bg-gray-700 rounded-xl p-4 space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">مشتری</span>
              <span className="font-bold">{order.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">تماس</span>
              <span>{order.customerPhone}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">نوع لباس</span>
              <span className="font-bold">{order.clothingType}</span>
            </div>
            {order.fabricColor && (
              <div className="flex justify-between">
                <span className="text-gray-500 dark:text-gray-400">رنگ پارچه</span>
                <span>{order.fabricColor}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">تاریخ ثبت</span>
              <span>{order.orderDate}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">تاریخ تحویل</span>
              <span className="font-bold">{order.deliveryDate}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">وضعیت</span>
              <span className="font-bold">{statusLabel(order.status)}</span>
            </div>
          </div>

          {/* Financial */}
          <div className="bg-green-50 dark:bg-emerald-900/20 rounded-xl p-4 space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">مبلغ کل</span>
              <span className="font-bold text-lg">{Number(order.totalAmount).toLocaleString()} تومان</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">بیعانه</span>
              <span>{Number(order.advancePaid).toLocaleString()} تومان</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500 dark:text-gray-400">باقی‌مانده</span>
              <span className="font-bold text-lg text-rose-600">
                {Number(order.remainingAmount).toLocaleString()} تومان
              </span>
            </div>
          </div>

          {/* Measurements */}
          {hasMeasurements && (
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4">
              <h3 className="font-bold text-gray-700 dark:text-gray-200 mb-2">📏 اندازه‌ها</h3>
              <div className="grid grid-cols-2 gap-2">
                {measFields.map(({ key, label }) =>
                  measurements![key as keyof Measurement] ? (
                    <div key={key} className="flex justify-between bg-white dark:bg-gray-700 rounded-lg px-3 py-1.5">
                      <span className="text-gray-500 dark:text-gray-400 text-sm">{label}</span>
                      <span className="font-semibold">{measurements![key]} سانتی‌متر</span>
                    </div>
                  ) : null
                )}
              </div>
            </div>
          )}

          {/* Photos */}
          {photos.length > 0 && (
            <div>
              <h3 className="font-bold text-gray-700 dark:text-gray-200 mb-2">📸 عکس‌های مدل</h3>
              <div className="flex flex-wrap gap-2">
                {photos.map((p) => (
                  <a key={p.id} href={p.dataUrl} target="_blank" rel="noopener noreferrer">
                    <img
                      src={p.dataUrl}
                      alt="مدل لباس"
                      className="w-24 h-24 rounded-xl object-cover border border-gray-200 dark:border-gray-600 hover:scale-105 transition-transform"
                    />
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {order.notes && (
            <div className="bg-amber-50 dark:bg-amber-900/20 rounded-xl p-4">
              <h3 className="font-bold text-gray-700 dark:text-gray-200 mb-1">📝 توضیحات</h3>
              <p className="text-gray-600 dark:text-gray-300 whitespace-pre-wrap">{order.notes}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
