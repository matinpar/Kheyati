"use client";

import { useState, useEffect } from "react";
import { Scissors, PackageCheck, Truck, Clock, AlertTriangle } from "lucide-react";
import { Tab } from "@/app/page";

interface Stats {
  inProgress: number;
  ready: number;
  delivered: number;
}

interface OrderSummary {
  id: number;
  customerName: string;
  clothingType: string;
  deliveryDate: string;
  status: string;
  remainingAmount: string;
}

interface DashboardTabProps {
  onTabChange: (tab: Tab) => void;
}

export default function DashboardTab({ onTabChange }: DashboardTabProps) {
  const [stats, setStats] = useState<Stats>({ inProgress: 0, ready: 0, delivered: 0 });
  const [upcomingOrders, setUpcomingOrders] = useState<OrderSummary[]>([]);

  useEffect(() => {
    fetchStats();
    fetchUpcoming();
  }, []);

  async function fetchStats() {
    try {
      const res = await fetch("/api/stats");
      const data = await res.json();
      if (!data.error) setStats(data);
    } catch {}
  }

  async function fetchUpcoming() {
    try {
      const res = await fetch("/api/orders?upcoming=true");
      const data = await res.json();
      if (!data.error) {
        const sorted = data
          .filter((o: OrderSummary) => o.status !== "delivered")
          .sort(
            (a: OrderSummary, b: OrderSummary) =>
              new Date(a.deliveryDate).getTime() - new Date(b.deliveryDate).getTime()
          )
          .slice(0, 8);
        setUpcomingOrders(sorted);
      }
    } catch {}
  }

  const today = new Date().toISOString().split("T")[0];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-3 gap-3">
        <button
          onClick={() => onTabChange("orders")}
          className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-rose-200 dark:border-gray-700 text-center hover:shadow-md transition-all"
        >
          <div className="flex justify-center mb-2">
            <div className="w-12 h-12 rounded-full bg-orange-100 dark:bg-orange-900/50 flex items-center justify-center">
              <Scissors size={24} className="text-orange-600 dark:text-orange-400" />
            </div>
          </div>
          <div className="text-3xl font-bold text-orange-600 dark:text-orange-400">{stats.inProgress}</div>
          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">در حال دوخت</div>
        </button>

        <button
          onClick={() => onTabChange("orders")}
          className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-rose-200 dark:border-gray-700 text-center hover:shadow-md transition-all"
        >
          <div className="flex justify-center mb-2">
            <div className="w-12 h-12 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center">
              <PackageCheck size={24} className="text-green-600 dark:text-green-400" />
            </div>
          </div>
          <div className="text-3xl font-bold text-green-600 dark:text-green-400">{stats.ready}</div>
          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">آماده تحویل</div>
        </button>

        <button
          onClick={() => onTabChange("orders")}
          className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-rose-200 dark:border-gray-700 text-center hover:shadow-md transition-all"
        >
          <div className="flex justify-center mb-2">
            <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center">
              <Truck size={24} className="text-blue-600 dark:text-blue-400" />
            </div>
          </div>
          <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">{stats.delivered}</div>
          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">تحویل داده شده</div>
        </button>
      </div>

      {/* Upcoming Deliveries */}
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 shadow-sm border border-rose-200 dark:border-gray-700">
        <h2 className="text-lg font-bold text-gray-800 dark:text-gray-100 mb-4 flex items-center gap-2">
          <Clock size={22} className="text-rose-600" />
          سفارش‌های نزدیک به موعد تحویل
        </h2>

        {upcomingOrders.length === 0 ? (
          <p className="text-center text-gray-400 dark:text-gray-500 py-6 text-lg">
            سفارش نزدیک به موعدی وجود ندارد ✨
          </p>
        ) : (
          <div className="space-y-2">
            {upcomingOrders.map((order) => {
              const deliveryDate = order.deliveryDate;
              const isOverdue = deliveryDate < today;
              const isToday = deliveryDate === today;

              return (
                <div
                  key={order.id}
                  className={`flex items-center justify-between p-3 rounded-xl border transition-all ${
                    isOverdue
                      ? "border-red-300 dark:border-red-700 bg-red-50 dark:bg-red-900/20"
                      : isToday
                      ? "border-amber-300 dark:border-amber-700 bg-amber-50 dark:bg-amber-900/20"
                      : "border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700/50"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {isOverdue ? (
                      <AlertTriangle size={20} className="text-red-500" />
                    ) : (
                      <Clock size={20} className={isToday ? "text-amber-500" : "text-gray-400"} />
                    )}
                    <div>
                      <p className="font-semibold text-gray-800 dark:text-gray-100">
                        {order.clothingType}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {order.customerName}
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p
                      className={`text-sm font-bold ${
                        isOverdue
                          ? "text-red-600 dark:text-red-400"
                          : isToday
                          ? "text-amber-600 dark:text-amber-400"
                          : "text-gray-600 dark:text-gray-400"
                      }`}
                    >
                      {deliveryDate}
                    </p>
                    <p className="text-xs text-gray-400 dark:text-gray-500">
                      {order.status === "ready" ? "آماده تحویل" : "در حال دوخت"}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
