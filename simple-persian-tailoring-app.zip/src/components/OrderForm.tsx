"use client";

import { useState, useEffect, useRef } from "react";
import toast from "react-hot-toast";
import { X, Camera, Trash2, Plus } from "lucide-react";
import type { Order, Customer, Measurement, OrderPhoto } from "@/lib/api";

interface OrderFormProps {
  order: Order | null;
  customers: Customer[];
  onClose: () => void;
  onSaved: () => void;
}

const emptyMeasurement: Measurement = {
  bust: "",
  waist: "",
  hips: "",
  shoulder: "",
  sleeveLength: "",
  dressLength: "",
  pantsLength: "",
  other: "",
};

const clothingTypes = [
  "مانتو",
  "پالتو",
  "کت و دامن",
  "پیراهن",
  "شلوار",
  "شومیز",
  "لباس شب",
  "لباس عروس",
  "سارافون",
  "تاپ",
  "دامن",
  "سایر",
];

export default function OrderForm({ order, customers, onClose, onSaved }: OrderFormProps) {
  const isEdit = !!order;

  const [customerId, setCustomerId] = useState<number | "">(order?.customerId ?? "");
  const [clothingType, setClothingType] = useState(order?.clothingType ?? "");
  const [customType, setCustomType] = useState("");
  const [fabricColor, setFabricColor] = useState(order?.fabricColor ?? "");
  const [orderDate, setOrderDate] = useState(order?.orderDate ?? new Date().toISOString().split("T")[0]);
  const [deliveryDate, setDeliveryDate] = useState(order?.deliveryDate ?? "");
  const [totalAmount, setTotalAmount] = useState(order?.totalAmount ? Number(order.totalAmount) : 0);
  const [advancePaid, setAdvancePaid] = useState(order?.advancePaid ? Number(order.advancePaid) : 0);
  const [remainingAmount, setRemainingAmount] = useState(order?.remainingAmount ? Number(order.remainingAmount) : 0);
  const [status, setStatus] = useState(order?.status ?? "in_progress");
  const [notes, setNotes] = useState(order?.notes ?? "");

  const [measurements, setMeasurements] = useState<Measurement>(emptyMeasurement);
  const [photos, setPhotos] = useState<string[]>([]);
  const [existingPhotos, setExistingPhotos] = useState<OrderPhoto[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch existing measurements and photos when editing
  useEffect(() => {
    if (order) {
      fetch(`/api/orders/${order.id}/measurements`)
        .then((r) => r.json())
        .then((data) => {
          if (data && !data.error) setMeasurements(data);
        })
        .catch(() => {});
      fetch(`/api/orders/${order.id}/photos`)
        .then((r) => r.json())
        .then((data) => {
          if (data && !data.error) setExistingPhotos(data);
        })
        .catch(() => {});
    }
  }, [order]);

  function handleTotalBlur() {
    const remaining = totalAmount - advancePaid;
    setRemainingAmount(remaining > 0 ? remaining : 0);
  }

  function handleAdvanceBlur() {
    const remaining = totalAmount - advancePaid;
    setRemainingAmount(remaining > 0 ? remaining : 0);
  }

  function handlePhotoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files) return;

    for (const file of Array.from(files)) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error("حجم تصویر نباید بیشتر از ۵ مگابایت باشد");
        continue;
      }
      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        if (dataUrl) setPhotos((prev) => [...prev, dataUrl]);
      };
      reader.readAsDataURL(file);
    }
  }

  function removePhoto(index: number) {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  }

  function removeExistingPhoto(photoId: number) {
    setExistingPhotos((prev) => prev.filter((p) => p.id !== photoId));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!customerId) {
      toast.error("لطفاً مشتری را انتخاب کنید");
      return;
    }
    if (!clothingType && !customType) {
      toast.error("لطفاً نوع لباس را مشخص کنید");
      return;
    }
    if (!deliveryDate) {
      toast.error("لطفاً تاریخ تحویل را مشخص کنید");
      return;
    }

    const finalType = clothingType === "سایر" ? customType : clothingType;
    const allPhotos = [...existingPhotos.map((p) => p.dataUrl), ...photos];

    const payload = {
      customerId,
      clothingType: finalType,
      fabricColor,
      orderDate,
      deliveryDate,
      totalAmount: String(totalAmount),
      advancePaid: String(advancePaid),
      remainingAmount: String(remainingAmount),
      status,
      notes,
      measurements,
      photos: allPhotos,
    };

    try {
      const url = "/api/orders";
      const method = isEdit ? "PUT" : "POST";
      const body = isEdit ? { ...payload, id: order!.id } : payload;

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();

      if (data.error) {
        toast.error(data.error);
        return;
      }

      toast.success(isEdit ? "سفارش ویرایش شد ✅" : "سفارش ثبت شد ✅");
      onSaved();
    } catch {
      toast.error("خطا در ثبت سفارش");
    }
  }

  const measFields = [
    { key: "bust" as const, label: "دور سینه" },
    { key: "waist" as const, label: "دور کمر" },
    { key: "hips" as const, label: "دور باسن" },
    { key: "shoulder" as const, label: "سرشانه" },
    { key: "sleeveLength" as const, label: "قد آستین" },
    { key: "dressLength" as const, label: "قد لباس" },
    { key: "pantsLength" as const, label: "قد شلوار" },
    { key: "other" as const, label: "سایر اندازه‌ها" },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 overflow-y-auto py-4">
      <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-xl mx-4 shadow-2xl my-4">
        <div className="sticky top-0 bg-white dark:bg-gray-800 rounded-t-2xl border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">
            {isEdit ? "ویرایش سفارش" : "ثبت سفارش جدید"}
          </h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
            <X size={22} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4 overflow-y-auto max-h-[75vh]">
          {/* Customer */}
          <div>
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">مشتری *</label>
            <select
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value ? Number(e.target.value) : "")}
              required
              className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
            >
              <option value="">انتخاب مشتری...</option>
              {customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} – {c.phone}
                </option>
              ))}
            </select>
          </div>

          {/* Clothing Type */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">نوع لباس *</label>
              <select
                value={clothingType}
                onChange={(e) => setClothingType(e.target.value)}
                className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
              >
                <option value="">انتخاب کنید...</option>
                {clothingTypes.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
            {clothingType === "سایر" && (
              <div>
                <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">نوع لباس (دلخواه)</label>
                <input
                  type="text"
                  value={customType}
                  onChange={(e) => setCustomType(e.target.value)}
                  className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">رنگ پارچه</label>
              <input
                type="text"
                value={fabricColor}
                onChange={(e) => setFabricColor(e.target.value)}
                className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">تاریخ ثبت</label>
              <input
                type="date"
                value={orderDate}
                onChange={(e) => setOrderDate(e.target.value)}
                className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">تاریخ تحویل *</label>
              <input
                type="date"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
                required
                className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>
          </div>

          {/* Amounts */}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">مبلغ کل (تومان)</label>
              <input
                type="number"
                value={totalAmount}
                onChange={(e) => setTotalAmount(Number(e.target.value))}
                onBlur={handleTotalBlur}
                className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">بیعانه</label>
              <input
                type="number"
                value={advancePaid}
                onChange={(e) => setAdvancePaid(Number(e.target.value))}
                onBlur={handleAdvanceBlur}
                className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">مبلغ باقی‌مانده</label>
              <input
                type="number"
                value={remainingAmount}
                onChange={(e) => setRemainingAmount(Number(e.target.value))}
                className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-rose-50 dark:bg-gray-700 text-lg font-bold text-rose-600 focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>
          </div>

          {/* Status */}
          <div>
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">وضعیت</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
            >
              <option value="in_progress">🧵 در حال دوخت</option>
              <option value="ready">✅ آماده تحویل</option>
              <option value="delivered">🚚 تحویل داده شده</option>
            </select>
          </div>

          {/* Measurements */}
          <div>
            <h3 className="text-base font-bold text-gray-700 dark:text-gray-200 mb-2">📏 اندازه‌های خیاطی</h3>
            <div className="grid grid-cols-2 gap-2">
              {measFields.map(({ key, label }) => (
                <div key={key}>
                  <label className="block text-xs text-gray-500 dark:text-gray-400 mb-1">{label} (سانتی‌متر)</label>
                  <input
                    type="text"
                    value={measurements[key]}
                    onChange={(e) => setMeasurements((prev) => ({ ...prev, [key]: e.target.value }))}
                    placeholder={label}
                    className="w-full p-2.5 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-base focus:outline-none focus:ring-2 focus:ring-rose-400"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Photos */}
          <div>
            <h3 className="text-base font-bold text-gray-700 dark:text-gray-200 mb-2">📸 عکس‌های مدل لباس</h3>
            <div className="flex flex-wrap gap-2 mb-2">
              {existingPhotos.map((p) => (
                <div key={p.id} className="relative w-20 h-20 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-600">
                  <img src={p.dataUrl} alt="" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => removeExistingPhoto(p.id)}
                    className="absolute top-0.5 right-0.5 bg-red-500 text-white rounded-full p-0.5"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
              {photos.map((p, i) => (
                <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden border border-gray-200 dark:border-gray-600">
                  <img src={p} alt="" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => removePhoto(i)}
                    className="absolute top-0.5 right-0.5 bg-red-500 text-white rounded-full p-0.5"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-20 h-20 rounded-xl border-2 border-dashed border-gray-300 dark:border-gray-600 flex items-center justify-center text-gray-400 hover:border-rose-400 hover:text-rose-500 transition-colors"
              >
                <Plus size={28} />
              </button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handlePhotoUpload}
              className="hidden"
            />
            <p className="text-xs text-gray-400">حداکثر حجم هر تصویر: ۵ مگابایت</p>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">توضیحات</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none"
              placeholder="توضیحات اضافی..."
            />
          </div>

          {/* Submit */}
          <button
            type="submit"
            className="w-full py-4 rounded-xl bg-rose-600 text-white text-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200 dark:shadow-rose-900/30"
          >
            {isEdit ? "💾 ذخیره تغییرات" : "✅ ثبت سفارش"}
          </button>
        </form>
      </div>
    </div>
  );
}
