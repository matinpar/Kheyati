"use client";

import { useState, useEffect, useCallback } from "react";
import toast from "react-hot-toast";
import { Plus, Search, X, Edit3, Trash2, Camera, Eye } from "lucide-react";
import OrderForm from "./OrderForm";
import OrderDetail from "./OrderDetail";
import type { Order, Customer } from "@/lib/api";

export default function OrdersTab() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [showForm, setShowForm] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [viewingOrder, setViewingOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchOrders = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (statusFilter !== "all") params.set("status", statusFilter);
      const res = await fetch(`/api/orders?${params.toString()}`);
      const data = await res.json();
      if (!data.error) setOrders(data);
    } catch {
      toast.error("خطا در دریافت سفارش‌ها");
    } finally {
      setLoading(false);
    }
  }, [search, statusFilter]);

  const fetchCustomers = useCallback(async () => {
    try {
      const res = await fetch("/api/customers");
      const data = await res.json();
      if (!data.error) setCustomers(data);
    } catch {}
  }, []);

  useEffect(() => {
    fetchOrders();
    fetchCustomers();
  }, [fetchOrders, fetchCustomers]);

  async function handleDelete(orderId: number) {
    if (!confirm("آیا از حذف این سفارش اطمینان دارید؟")) return;
    try {
      const res = await fetch(`/api/orders?id=${orderId}`, { method: "DELETE" });
      const data = await res.json();
      if (data.ok) {
        toast.success("سفارش حذف شد");
        fetchOrders();
      }
    } catch {
      toast.error("خطا در حذف سفارش");
    }
  }

  async function handleStatusChange(orderId: number, newStatus: string) {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    try {
      const res = await fetch("/api/orders", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...order, status: newStatus, photos: undefined }),
      });
      const data = await res.json();
      if (!data.error) {
        toast.success(
          newStatus === "in_progress"
            ? "وضعیت به «در حال دوخت» تغییر کرد"
            : newStatus === "ready"
            ? "وضعیت به «آماده تحویل» تغییر کرد"
            : "وضعیت به «تحویل داده شده» تغییر کرد"
        );
        fetchOrders();
      }
    } catch {
      toast.error("خطا در تغییر وضعیت");
    }
  }

  function handleEdit(order: Order) {
    setEditingOrder(order);
    setShowForm(true);
  }

  function handleNew() {
    setEditingOrder(null);
    setShowForm(true);
  }

  const statusLabel = (s: string) =>
    s === "in_progress" ? "در حال دوخت" : s === "ready" ? "آماده تحویل" : "تحویل داده شده";

  const statusColor = (s: string) =>
    s === "in_progress"
      ? "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300"
      : s === "ready"
      ? "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300"
      : "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300";

  const today = new Date().toISOString().split("T")[0];

  return (
    <div className="space-y-4">
      {/* Search & Filter */}
      <div className="flex gap-2 flex-wrap">
        <div className="flex-1 relative min-w-[200px]">
          <Search size={20} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="جستجوی مشتری یا شماره تماس..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-10 pl-4 py-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="py-3 px-4 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
        >
          <option value="all">همه وضعیت‌ها</option>
          <option value="in_progress">در حال دوخت</option>
          <option value="ready">آماده تحویل</option>
          <option value="delivered">تحویل داده شده</option>
        </select>
        <button
          onClick={handleNew}
          className="py-3 px-5 rounded-xl bg-rose-600 text-white text-lg font-medium flex items-center gap-2 hover:bg-rose-700 transition-all shadow-lg shadow-rose-200 dark:shadow-rose-900/30"
        >
          <Plus size={22} />
          سفارش جدید
        </button>
      </div>

      {/* Order List */}
      {loading ? (
        <div className="text-center py-12 text-gray-400 text-lg">در حال بارگذاری...</div>
      ) : orders.length === 0 ? (
        <div className="text-center py-12 text-gray-400 dark:text-gray-500 text-lg">
          هیچ سفارشی یافت نشد 🧵
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => {
            const isOverdue = order.deliveryDate < today && order.status !== "delivered";
            const isToday = order.deliveryDate === today;

            return (
              <div
                key={order.id}
                className={`bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border transition-all ${
                  isOverdue
                    ? "border-red-300 dark:border-red-700"
                    : "border-rose-200 dark:border-gray-700"
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="text-lg font-bold text-gray-800 dark:text-gray-100">
                        {order.clothingType}
                      </h3>
                      <span
                        className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor(order.status)}`}
                      >
                        {statusLabel(order.status)}
                      </span>
                      {isOverdue && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300">
                          عقب افتاده
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {order.customerName} – {order.customerPhone}
                    </p>
                    <div className="flex gap-3 mt-2 text-sm text-gray-600 dark:text-gray-300 flex-wrap">
                      {order.fabricColor && <span>🎨 {order.fabricColor}</span>}
                      <span>📅 ثبت: {order.orderDate}</span>
                      <span className={isOverdue ? "text-red-600 font-bold" : isToday ? "text-amber-600 font-bold" : ""}>
                        ⏰ تحویل: {order.deliveryDate}
                      </span>
                      <span>💰 {Number(order.totalAmount).toLocaleString()} تومان</span>
                      {Number(order.remainingAmount) > 0 && (
                        <span className="text-rose-600 font-semibold">
                          مانده: {Number(order.remainingAmount).toLocaleString()} تومان
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button
                      onClick={() => setViewingOrder(order)}
                      className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500"
                      title="مشاهده جزئیات"
                    >
                      <Eye size={18} />
                    </button>
                    <button
                      onClick={() => handleEdit(order)}
                      className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500"
                      title="ویرایش"
                    >
                      <Edit3 size={18} />
                    </button>
                    <button
                      onClick={() => handleDelete(order.id)}
                      className="p-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500"
                      title="حذف"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>

                {/* Status Change Buttons */}
                {order.status !== "delivered" && (
                  <div className="flex gap-2 mt-3 pt-3 border-t border-gray-100 dark:border-gray-700">
                    {order.status === "in_progress" && (
                      <button
                        onClick={() => handleStatusChange(order.id, "ready")}
                        className="flex-1 py-2 rounded-lg bg-green-500 text-white font-medium text-sm hover:bg-green-600 transition-all"
                      >
                        ✅ آماده تحویل شد
                      </button>
                    )}
                    {order.status === "ready" && (
                      <button
                        onClick={() => handleStatusChange(order.id, "delivered")}
                        className="flex-1 py-2 rounded-lg bg-blue-500 text-white font-medium text-sm hover:bg-blue-600 transition-all"
                      >
                        🚚 تحویل داده شد
                      </button>
                    )}
                    {order.status === "in_progress" && (
                      <button
                        onClick={() => handleStatusChange(order.id, "delivered")}
                        className="flex-1 py-2 rounded-lg bg-blue-500 text-white font-medium text-sm hover:bg-blue-600 transition-all"
                      >
                        🚚 تحویل داده شد
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* New/Edit Order Modal */}
      {showForm && (
        <OrderForm
          order={editingOrder}
          customers={customers}
          onClose={() => {
            setShowForm(false);
            setEditingOrder(null);
          }}
          onSaved={() => {
            setShowForm(false);
            setEditingOrder(null);
            fetchOrders();
            fetchCustomers();
          }}
        />
      )}

      {/* View Order Detail */}
      {viewingOrder && (
        <OrderDetail
          order={viewingOrder}
          onClose={() => setViewingOrder(null)}
          onEdit={(order) => {
            setViewingOrder(null);
            handleEdit(order);
          }}
        />
      )}
    </div>
  );
}
