"use client";

import { useState, useEffect, useCallback } from "react";
import toast from "react-hot-toast";
import { Plus, Search, Edit3, Trash2, Eye, X, User } from "lucide-react";
import type { Customer, Order } from "@/lib/api";

export default function CustomersTab() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewingCustomer, setViewingCustomer] = useState<Customer | null>(null);
  const [customerOrders, setCustomerOrders] = useState<Order[]>([]);

  // Form state
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");

  const fetchCustomers = useCallback(async () => {
    try {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      const res = await fetch(`/api/customers?${params.toString()}`);
      const data = await res.json();
      if (!data.error) setCustomers(data);
    } catch {
      toast.error("خطا در دریافت مشتریان");
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    fetchCustomers();
  }, [fetchCustomers]);

  function handleNew() {
    setEditingCustomer(null);
    setName("");
    setPhone("");
    setAddress("");
    setNotes("");
    setShowForm(true);
  }

  function handleEdit(customer: Customer) {
    setEditingCustomer(customer);
    setName(customer.name);
    setPhone(customer.phone);
    setAddress(customer.address || "");
    setNotes(customer.notes || "");
    setShowForm(true);
  }

  async function handleDelete(id: number) {
    if (!confirm("آیا از حذف این مشتری اطمینان دارید؟ تمام سفارش‌های مرتبط نیز حذف خواهند شد.")) return;
    try {
      const res = await fetch(`/api/customers?id=${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.ok) {
        toast.success("مشتری حذف شد");
        fetchCustomers();
      }
    } catch {
      toast.error("خطا در حذف مشتری");
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.error("نام و شماره تماس الزامی است");
      return;
    }

    try {
      const url = "/api/customers";
      const method = editingCustomer ? "PUT" : "POST";
      const body = editingCustomer
        ? { id: editingCustomer.id, name, phone, address, notes }
        : { name, phone, address, notes };

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();

      if (data.error) {
        toast.error(data.error);
        return;
      }

      toast.success(editingCustomer ? "مشتری ویرایش شد ✅" : "مشتری ثبت شد ✅");
      setShowForm(false);
      fetchCustomers();
    } catch {
      toast.error("خطا در ثبت مشتری");
    }
  }

  async function viewCustomerHistory(customer: Customer) {
    setViewingCustomer(customer);
    try {
      const res = await fetch(`/api/orders?customerId=${customer.id}`);
      const data = await res.json();
      if (!data.error) setCustomerOrders(data);
    } catch {
      toast.error("خطا در دریافت سوابق");
    }
  }

  const statusLabel = (s: string) =>
    s === "in_progress" ? "در حال دوخت" : s === "ready" ? "آماده تحویل" : "تحویل داده شده";

  const statusColor = (s: string) =>
    s === "in_progress"
      ? "bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300"
      : s === "ready"
      ? "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300"
      : "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300";

  return (
    <div className="space-y-4">
      {/* Search & Add */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search size={20} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="جستجوی نام یا شماره تماس..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-10 pl-4 py-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-800 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
          />
        </div>
        <button
          onClick={handleNew}
          className="py-3 px-5 rounded-xl bg-rose-600 text-white text-lg font-medium flex items-center gap-2 hover:bg-rose-700 transition-all shadow-lg shadow-rose-200 dark:shadow-rose-900/30"
        >
          <Plus size={22} />
          مشتری جدید
        </button>
      </div>

      {/* Customer List */}
      {loading ? (
        <div className="text-center py-12 text-gray-400 text-lg">در حال بارگذاری...</div>
      ) : customers.length === 0 ? (
        <div className="text-center py-12 text-gray-400 dark:text-gray-500 text-lg">
          هیچ مشتری یافت نشد 👤
        </div>
      ) : (
        <div className="space-y-2">
          {customers.map((c) => (
            <div
              key={c.id}
              className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-rose-200 dark:border-gray-700 flex items-center justify-between gap-3"
            >
              <button
                onClick={() => viewCustomerHistory(c)}
                className="flex items-center gap-3 flex-1 min-w-0 text-right"
              >
                <div className="w-12 h-12 rounded-full bg-rose-100 dark:bg-rose-900/40 flex items-center justify-center flex-shrink-0">
                  <User size={22} className="text-rose-600 dark:text-rose-400" />
                </div>
                <div className="min-w-0">
                  <p className="text-lg font-bold text-gray-800 dark:text-gray-100 truncate">{c.name}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{c.phone}</p>
                </div>
              </button>
              <div className="flex items-center gap-1 flex-shrink-0">
                <button
                  onClick={() => viewCustomerHistory(c)}
                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500"
                  title="سوابق"
                >
                  <Eye size={18} />
                </button>
                <button
                  onClick={() => handleEdit(c)}
                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500"
                  title="ویرایش"
                >
                  <Edit3 size={18} />
                </button>
                <button
                  onClick={() => handleDelete(c.id)}
                  className="p-2 rounded-lg hover:bg-red-100 dark:hover:bg-red-900/30 text-red-500"
                  title="حذف"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit Customer Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 overflow-y-auto py-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-md mx-4 shadow-2xl my-4">
            <div className="sticky top-0 bg-white dark:bg-gray-800 rounded-t-2xl border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">
                {editingCustomer ? "ویرایش مشتری" : "ثبت مشتری جدید"}
              </h2>
              <button
                onClick={() => setShowForm(false)}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <X size={22} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">
                  نام و نام خانوادگی *
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
                  placeholder="نام کامل مشتری"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">
                  شماره تماس *
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                  className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400"
                  placeholder="مثلاً ۰۹۱۲۳۴۵۶۷۸۹"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">
                  آدرس (اختیاری)
                </label>
                <textarea
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  rows={2}
                  className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none"
                  placeholder="آدرس مشتری"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">
                  توضیحات
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  className="w-full p-3 rounded-xl border border-rose-200 dark:border-gray-600 bg-white dark:bg-gray-700 text-lg focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none"
                  placeholder="یادداشت‌های مربوط به مشتری"
                />
              </div>
              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-rose-600 text-white text-xl font-bold hover:bg-rose-700 transition-all shadow-lg shadow-rose-200 dark:shadow-rose-900/30"
              >
                {editingCustomer ? "💾 ذخیره تغییرات" : "✅ ثبت مشتری"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* View Customer History */}
      {viewingCustomer && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 overflow-y-auto py-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl w-full max-w-lg mx-4 shadow-2xl my-4">
            <div className="sticky top-0 bg-white dark:bg-gray-800 rounded-t-2xl border-b border-gray-200 dark:border-gray-700 p-4 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-gray-800 dark:text-gray-100">{viewingCustomer.name}</h2>
                <p className="text-sm text-gray-500 dark:text-gray-400">{viewingCustomer.phone}</p>
              </div>
              <button
                onClick={() => setViewingCustomer(null)}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <X size={22} />
              </button>
            </div>

            <div className="p-4 space-y-2 overflow-y-auto max-h-[70vh]">
              {customerOrders.length === 0 ? (
                <p className="text-center text-gray-400 dark:text-gray-500 py-8 text-lg">
                  هیچ سفارشی برای این مشتری ثبت نشده است
                </p>
              ) : (
                <>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                    تعداد کل سفارش‌ها: {customerOrders.length}
                  </p>
                  {customerOrders.map((o) => (
                    <div
                      key={o.id}
                      className="bg-rose-50 dark:bg-gray-700 rounded-xl p-3 space-y-1"
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-bold">{o.clothingType}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${statusColor(o.status)}`}>
                          {statusLabel(o.status)}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400">
                        <span>📅 ثبت: {o.orderDate}</span>
                        <span>⏰ تحویل: {o.deliveryDate}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>💰 {Number(o.totalAmount).toLocaleString()} تومان</span>
                        {Number(o.remainingAmount) > 0 && (
                          <span className="text-rose-600 font-semibold">
                            مانده: {Number(o.remainingAmount).toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
