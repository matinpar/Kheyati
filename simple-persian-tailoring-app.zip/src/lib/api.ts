// Shared API helpers

export interface Customer {
  id: number;
  name: string;
  phone: string;
  address: string;
  notes: string;
  createdAt: string;
}

export interface Order {
  id: number;
  customerId: number;
  clothingType: string;
  fabricColor: string;
  orderDate: string;
  deliveryDate: string;
  totalAmount: string;
  advancePaid: string;
  remainingAmount: string;
  status: string;
  notes: string;
  createdAt: string;
  customerName?: string;
  customerPhone?: string;
}

export interface Measurement {
  id?: number;
  orderId?: number;
  bust: string;
  waist: string;
  hips: string;
  shoulder: string;
  sleeveLength: string;
  dressLength: string;
  pantsLength: string;
  other: string;
}

export interface OrderPhoto {
  id: number;
  orderId: number;
  dataUrl: string;
  createdAt: string;
}

export async function fetchJSON<T>(url: string, options?: RequestInit): Promise<T> {
  const res = await fetch(url, options);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "خطا در ارتباط با سرور" }));
    throw new Error(err.error || "خطای ناشناخته");
  }
  return res.json();
}
